
package Classes;

public interface SalaVirtual {
    public String login();
    public String logout();
}
