
package Classes;

public enum EnumGenero {
    MASCULINO, FEMININO;
}
